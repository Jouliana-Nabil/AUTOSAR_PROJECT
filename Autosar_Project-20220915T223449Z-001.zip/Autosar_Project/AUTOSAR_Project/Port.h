/*-----------------------------------------------------------------------------
*[Module]: Port
* 
*[File Name]: Port.h
* 
*[Description]: Header file for TM4C123GH6PM Microcontroller - Port Driver. 
* 
*[Author]: Jouliana Nabil Shawky
*
------------------------------------------------------------------------------*/

#ifndef PORT_H
#define PORT_H

/* ID for the company in the AUTOSAR */
#define PORT_VENDOR_ID    (1000U)

/* Port Module Id */
#define PORT_MODULE_ID    (100U)

/* Port Instance Id */
#define PORT_INSTANCE_ID  (0U)

/*
 * Module Version 1.0.0
 */
#define PORT_SW_MAJOR_VERSION           (1U)
#define PORT_SW_MINOR_VERSION           (0U)
#define PORT_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define PORT_AR_RELEASE_MAJOR_VERSION   (4U)
#define PORT_AR_RELEASE_MINOR_VERSION   (0U)
#define PORT_AR_RELEASE_PATCH_VERSION   (3U)


/* Standard AUTOSAR types */
#include "Std_Types.h"

/* AUTOSAR checking between Std Types and Port Modules */
#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != PORT_AR_RELEASE_MAJOR_VERSION)\
 ||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != PORT_AR_RELEASE_MINOR_VERSION)\
 ||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != PORT_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of Std_Types.h does not match the expected version"
#endif

/* Port Pre-Compile Configuration Header file */
#include "Port_Cfg.h"

/* AUTOSAR Version checking between Port_Cfg.h and Port.h files */
#if ((PORT_CFG_AR_RELEASE_MAJOR_VERSION != PORT_AR_RELEASE_MAJOR_VERSION)\
 ||  (PORT_CFG_AR_RELEASE_MINOR_VERSION != PORT_AR_RELEASE_MINOR_VERSION)\
 ||  (PORT_CFG_AR_RELEASE_PATCH_VERSION != PORT_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of Port_Cfg.h does not match the expected version"
#endif

/* Software Version checking between Dio_Cfg.h and Dio.h files */
#if ((PORT_CFG_SW_MAJOR_VERSION != PORT_SW_MAJOR_VERSION)\
 ||  (PORT_CFG_SW_MINOR_VERSION != PORT_SW_MINOR_VERSION)\
 ||  (PORT_CFG_SW_PATCH_VERSION != PORT_SW_PATCH_VERSION))
  #error "The SW version of Port_Cfg.h does not match the expected version"
#endif
/******************************************************************************
 *                       Services IDs                                         *
 ******************************************************************************/
/* Service ID for Port Initialization */
#define PORT_INIT_SID                    (uint8)0x00

/* Service ID for port pin Set direction */
#define PORT_SET_PIN_DIRECTION_SID       (uint8)0x01

/* Service ID for Port refresh direction */
#define PORT_REFRESH_PORT_DIRECTION_SID  (uint8)0x02

/* Service ID for Port get version information */
#define PORT_GET_VERSION_INFO_SID        (uint8)0x03

/* Service ID for Port pin Set mode */
#define PORT_SET_PIN_MODE_SID            (uint8)0x04
   
/******************************************************************************
 *                      Constants used in function implementation             *
 ******************************************************************************/
/* Shift amount*/
#define GPIO_PCTL_SHIFT_AMOUNT         (uint8)(4) 
#define GPIO_PCTL_PMCX_MASK            (uint32)(0x0000000F) 
/* Constants for the port status */
#define PORT_UNINITIALIZED             (uint8)(0)
#define PORT_INITIALIZED               (uint8)(1)
/* Number of pins available for configuration in PB*/   
#define PORT_PINS_NUMBER               (39U)
/* UnLock value */
#define PORT_UNLOCK_VALUE               0x4C4F434B
/*******************************************************************************
 *                      DET Error Codes                                        *
 *******************************************************************************/
/* DET code to report Invalid Port Pin ID requested*/
#define PORT_E_PARAM_PIN                (uint8)0x0A

/* DET code to report Port Pin not configured as changeable */
#define PORT_E_DIRECTION_UNCHANGEABLE   (uint8)0x0B

/* DET code to report API Port_Init service called with wrong parameter. */
#define PORT_E_PARAM_CONFIG             (uint8)0x0C

/* DET code to report API Port_SetPinMode service called when mode is unchangeable */
#define PORT_E_PARAM_INVALID_MODE       (uint8)0x0D
 
/* DET code to report API Port_SetPinMode service called when mode is unchangeable */
#define PORT_E_MODE_UNCHANGEABLE       (uint8)0x0E
   
/* DET code to reportAPI service called without module initialization */
#define PORT_E_UNINIT                  (uint8)0x0F

/* DET code to report APIs called with a Null Pointer */
#define PORT_E_PARAM_POINTER            (uint8)0x10
/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

/* Description: Enum to hold PIN direction */
typedef enum
{
    INPUT , OUTPUT
}Port_PinDirectionType;

/* Description: Enum to hold internal resistor type for PIN */
typedef enum
{
    OFF,PULL_UP,PULL_DOWN
}Port_InternalResistor;

/* Data type for the symbolic name of a port pin */
typedef uint8 Port_PinType;

/* Data type for Different port pin modes.*/
typedef uint8 Port_PinModeType;

/* Description: Structure to configure each individual PIN:
 *      1. the mode of the pin --> DIO , ADC , UART , ... 
 *	2. the PORT Which the pin belongs to. 0, 1, 2, 3, 4 or 5
 *	3. the number of the pin in the PORT.
 *      4. the direction of pin --> INPUT or OUTPUT
 *      5. the internal resistor --> Disable, Pull up or Pull down
 *      6. initial output value 
 *      7. changable direction or not 
 *      8. changable mode or not 
 */
typedef struct 
{
    Port_PinModeType pin_mode;
    uint8 port_num;
    uint8 port_pin_type;
    Port_PinDirectionType direction;
    Port_InternalResistor resistor;
    uint8 initial_value;
    uint8 port_pin_direction_changable;
    uint8 port_pin_mode_changable;
    
}Port_PinConfigType;

typedef struct 
{
      Port_PinConfigType Port_Pins[PORT_PINS_CONFIGURED];
}Port_ConfigType;

/* used with the APIs to operate on them */
#include "Common_Macros.h"

/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

/************************************************************************************
* Service Name: Port_Init
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant 
* Parameters (in): ConfigPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Initializes the Port Driver module. 
************************************************************************************/
void Port_Init( const Port_ConfigType* ConfigPtr );
/************************************************************************************
* Service Name: Port_SetPinDirection
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): Pin - Port  Pin ID number 
                   Direction - Port Pin Direction
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Sets the port pin direction.
************************************************************************************/
#if (PORT_SET_PIN_DIRECTION_API == STD_ON)
void Port_SetPinDirection( Port_PinType Pin, Port_PinDirectionType Direction ); 
#endif

/************************************************************************************
* Service Name: Port_RefreshPortDirection
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Refreshes port direction.
************************************************************************************/
void Port_RefreshPortDirection(void);
/************************************************************************************
* Service Name: Port_GetVersionInfo
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): versioninfo : Pointer to where to store the version information of this module.
* Return value: None
* Description: Returns the version information of this module. 
************************************************************************************/
#if (PORT_VERSION_INFO_API == STD_ON) 
void Port_GetVersionInfo(Std_VersionInfoType* versioninfo); 
#endif

/************************************************************************************
* Service Name: Port_SetPinMode
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): Pin - Port Pin ID number  
                   Mode - New Port Pin mode to be set on port pin.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Sets the port pin mode. 
************************************************************************************/
#if (PORT_SET_PIN_MODE_API == STD_ON)
void Port_SetPinMode( Port_PinType Pin, Port_PinModeType Mode); 
#endif

/*******************************************************************************
 *                       External Variables                                    *
 *******************************************************************************/

/* Extern PB structures to be used by Port and other modules */
extern const Port_ConfigType Port_Configuations;

#endif /* PORT_H */
