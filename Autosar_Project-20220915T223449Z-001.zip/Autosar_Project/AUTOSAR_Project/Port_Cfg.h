/*-----------------------------------------------------------------------------
*[Module]: Port
* 
*[File Name]: Port_Cfg.h
*
*[Description]: Pre-Compile Configuration Header file for TM4C123GH6PM Microcontroller - Port Driver
*
*[Author]: Jouliana Nabil Shawky
*
------------------------------------------------------------------------------*/

#ifndef PORT_CFG_H
#define PORT_CFG_H
//#include "Std_Types.h"
/*
 * Module Version 1.0.0
 */
#define PORT_CFG_SW_MAJOR_VERSION              (1U)
#define PORT_CFG_SW_MINOR_VERSION              (0U)
#define PORT_CFG_SW_PATCH_VERSION              (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define PORT_CFG_AR_RELEASE_MAJOR_VERSION     (4U)
#define PORT_CFG_AR_RELEASE_MINOR_VERSION     (0U)
#define PORT_CFG_AR_RELEASE_PATCH_VERSION     (3U)

/*******************************************************************************
 *  Port Pins Modes(used as inserted value in PMCx field in PCTL Register)     *
 *******************************************************************************/
#define PORT_PIN_MODE_DIO          (Port_PinModeType)(0x00)     
#define PORT_PIN_MODE_ADC          (Port_PinModeType)(0x0F) /* This is not reserved number for any mode /PMCx field */
#define PORT_PIN_MODE_UART_0       (Port_PinModeType)(0x01)
#define PORT_PIN_MODE_UART_1       (Port_PinModeType)(0x02) /* This mode is for PC5:4 to insert in PMCx bits value = 2 */
#define PORT_PIN_MODE_UART_2       (Port_PinModeType)(0x08) /* This mode is for PC5:4 to insert in PMCx bits value = 8 */
#define PORT_PIN_MODE_SSI_0        (Port_PinModeType)(0x01) /* This mode is for PD3:0 to insert in PMCx bits value = 1 */
#define PORT_PIN_MODE_SSI_1        (Port_PinModeType)(0x02)
#define PORT_PIN_MODE_I2C          (Port_PinModeType)(0x03)
#define PORT_PIN_MODE_PWM_0        (Port_PinModeType)(0x04)
#define PORT_PIN_MODE_PWM_1        (Port_PinModeType)(0x05) /* This mode is for Port A and F pins that support PWM , PD1:0 and PE5:4 to insert in PMCx bits value = 5 */
#define PORT_PIN_MODE_CAN_0        (Port_PinModeType)(0x03) /* This mode is for Port F pins that support CAN to insert in PMCx bits value = 3 */
#define PORT_PIN_MODE_CAN_1        (Port_PinModeType)(0x08)
#define PORT_PIN_MODE_GPT          (Port_PinModeType)(0x07)
#define PORT_PIN_MODE_USB          (Port_PinModeType)(0x08)  
#define PORT_PIN_MODE_QEI          (Port_PinModeType)(0x06)  
#define PORT_PIN_MODE_CORE         (Port_PinModeType)(0x0E)
#define PORT_PIN_MODE_COMPARATOR   (Port_PinModeType)(0x09) 
#define PORT_PIN_MODE_NMI          (Port_PinModeType)(0x08) 

/* Ports IDs */
#define PORT_ID_PORT_A      (uint8)(0) 
#define PORT_ID_PORT_B      (uint8)(1) 
#define PORT_ID_PORT_C      (uint8)(2) 
#define PORT_ID_PORT_D      (uint8)(3) 
#define PORT_ID_PORT_E      (uint8)(4) 
#define PORT_ID_PORT_F      (uint8)(5)

/* Pins indexes from 0 (MIN) :  7 (MAX)*/   
#define PORT_PIN_0          (uint8)(0) 
#define PORT_PIN_1          (uint8)(1) 
#define PORT_PIN_2          (uint8)(2) 
#define PORT_PIN_3          (uint8)(3) 
#define PORT_PIN_4          (uint8)(4) 
#define PORT_PIN_5          (uint8)(5) 
#define PORT_PIN_6          (uint8)(6) 
#define PORT_PIN_7          (uint8)(7) 

   
/* Port Pins IDs */
/* Indeces of pins numbers in PB struct */
#define PORT_A_PIN_0      (Port_PinType)(0U) 
#define PORT_A_PIN_1      (Port_PinType)(1U) 
#define PORT_A_PIN_2      (Port_PinType)(2U) 
#define PORT_A_PIN_3      (Port_PinType)(3U) 
#define PORT_A_PIN_4      (Port_PinType)(4U) 
#define PORT_A_PIN_5      (Port_PinType)(5U) 
#define PORT_A_PIN_6      (Port_PinType)(6U) 
#define PORT_A_PIN_7      (Port_PinType)(7U) 
#define PORT_B_PIN_0      (Port_PinType)(8U) 
#define PORT_B_PIN_1      (Port_PinType)(9U)  
#define PORT_B_PIN_2      (Port_PinType)(10U) 
#define PORT_B_PIN_3      (Port_PinType)(11U) 
#define PORT_B_PIN_4      (Port_PinType)(12U)  
#define PORT_B_PIN_5      (Port_PinType)(13U) 
#define PORT_B_PIN_6      (Port_PinType)(14U) 
#define PORT_B_PIN_7      (Port_PinType)(15U) 
#define PORT_C_PIN_4      (Port_PinType)(16U) 
#define PORT_C_PIN_5      (Port_PinType)(17U) 
#define PORT_C_PIN_6      (Port_PinType)(18U) 
#define PORT_C_PIN_7      (Port_PinType)(19U) 
#define PORT_D_PIN_0      (Port_PinType)(20U) 
#define PORT_D_PIN_1      (Port_PinType)(21U) 
#define PORT_D_PIN_2      (Port_PinType)(22U) 
#define PORT_D_PIN_3      (Port_PinType)(23U) 
#define PORT_D_PIN_4      (Port_PinType)(24U) 
#define PORT_D_PIN_5      (Port_PinType)(25U) 
#define PORT_D_PIN_6      (Port_PinType)(26U) 
#define PORT_D_PIN_7      (Port_PinType)(27U) 
#define PORT_E_PIN_0      (Port_PinType)(28U) 
#define PORT_E_PIN_1      (Port_PinType)(29U) 
#define PORT_E_PIN_2      (Port_PinType)(30U) 
#define PORT_E_PIN_3      (Port_PinType)(31U) 
#define PORT_E_PIN_4      (Port_PinType)(32U) 
#define PORT_E_PIN_5      (Port_PinType)(33U) 
#define PORT_F_PIN_0      (Port_PinType)(34U) 
#define PORT_F_PIN_1      (Port_PinType)(35U) 
#define PORT_F_PIN_2      (Port_PinType)(36U) 
#define PORT_F_PIN_3      (Port_PinType)(37U) 
#define PORT_F_PIN_4      (Port_PinType)(38U) 
   

/* Changability of Port pins direction */
#define PORT_A_PIN_0_CHANGEABLE_DIRECTION      (STD_ON)
#define PORT_A_PIN_1_CHANGEABLE_DIRECTION      (STD_ON)
#define PORT_A_PIN_2_CHANGEABLE_DIRECTION      (STD_ON)
#define PORT_A_PIN_3_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_A_PIN_4_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_A_PIN_5_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_A_PIN_6_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_A_PIN_7_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_0_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_1_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_2_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_3_CHANGEABLE_DIRECTION      (STD_ON)
#define PORT_B_PIN_4_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_5_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_B_PIN_6_CHANGEABLE_DIRECTION      (STD_ON)
#define PORT_B_PIN_7_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_0_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_1_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_2_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_3_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_4_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_5_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_6_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_C_PIN_7_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_0_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_1_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_2_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_3_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_4_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_5_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_6_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_D_PIN_7_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_0_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_1_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_2_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_3_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_4_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_E_PIN_5_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_F_PIN_0_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_F_PIN_1_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_F_PIN_2_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_F_PIN_3_CHANGEABLE_DIRECTION      (STD_ON) 
#define PORT_F_PIN_4_CHANGEABLE_DIRECTION      (STD_ON)

/* Changability of Port pins Mode */
#define PORT_A_PIN_0_CHANGEABLE_MODE      (STD_ON)
#define PORT_A_PIN_1_CHANGEABLE_MODE      (STD_ON)
#define PORT_A_PIN_2_CHANGEABLE_MODE      (STD_ON)
#define PORT_A_PIN_3_CHANGEABLE_MODE      (STD_ON) 
#define PORT_A_PIN_4_CHANGEABLE_MODE      (STD_ON) 
#define PORT_A_PIN_5_CHANGEABLE_MODE      (STD_ON) 
#define PORT_A_PIN_6_CHANGEABLE_MODE      (STD_ON) 
#define PORT_A_PIN_7_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_0_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_1_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_2_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_3_CHANGEABLE_MODE      (STD_ON)
#define PORT_B_PIN_4_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_5_CHANGEABLE_MODE      (STD_ON) 
#define PORT_B_PIN_6_CHANGEABLE_MODE      (STD_ON)
#define PORT_B_PIN_7_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_0_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_1_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_2_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_3_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_4_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_5_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_6_CHANGEABLE_MODE      (STD_ON) 
#define PORT_C_PIN_7_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_0_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_1_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_2_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_3_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_4_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_5_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_6_CHANGEABLE_MODE      (STD_ON) 
#define PORT_D_PIN_7_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_0_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_1_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_2_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_3_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_4_CHANGEABLE_MODE      (STD_ON) 
#define PORT_E_PIN_5_CHANGEABLE_MODE      (STD_ON) 
#define PORT_F_PIN_0_CHANGEABLE_MODE      (STD_ON) 
#define PORT_F_PIN_1_CHANGEABLE_MODE      (STD_ON) 
#define PORT_F_PIN_2_CHANGEABLE_MODE      (STD_ON) 
#define PORT_F_PIN_3_CHANGEABLE_MODE      (STD_ON) 
#define PORT_F_PIN_4_CHANGEABLE_MODE      (STD_ON)

/* Number of the configured Port Pins */
#define PORT_PINS_CONFIGURED           (39U) /* Excluded PC3:0*/

/* Pre-compile option for Development Error Detect */
#define PORT_DEV_ERROR_DETECT          (STD_ON)

/* Description : Pre-compile switch to enable/disable the API to read out the modules version information*/
#define PORT_VERSION_INFO_API          (STD_ON)
/* Description : Pre-compile switch to enable/disable PortSetPinDirection API */
#define PORT_SET_PIN_DIRECTION_API     (STD_ON)
/* Description : Pre-compile switch to enable/disable PortSetPinMode API */
#define PORT_SET_PIN_MODE_API          (STD_ON)
#endif /* PORT_CFG_H */
